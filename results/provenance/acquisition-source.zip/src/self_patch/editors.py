"""Conventional identification and an optional Prime-compatible LLM transport."""

import json
import math
import os
import re
import time
import urllib.error
import urllib.request

import numpy as np

from .controller import Controller
from .session import SYSTEM_PROMPT, EditSession, assignments
from .world import PHYSICS


def identify(session: EditSession) -> np.ndarray:
    """No privileged state: use the same two permitted probes as the LLM can use."""
    columns = []
    for action in ([1.0, 0.0], [0.0, 1.0]):
        result = session.execute("probe", {"action": action})
        columns.append(np.array(result["after"]["velocity"]) / PHYSICS.acceleration)
    return np.linalg.inv(np.column_stack(columns))


def analytic_editor(session: EditSession):
    """A diagnostic upper baseline; NOT a trained/self-improving language model."""
    before = Controller(session.execute("inspect_controller", {})["tensors"])
    inverse = identify(session)
    session.execute("apply_patch", {"edits": assignments(before, before.remap_output(inverse))})
    session.execute("commit", {})


class ChatEditor:
    """One JSON tool action per model turn, also used by the Verifiers environment.

    Credentials come from environment variables only. A custom URL is useful for
    evaluating exported trained weights served by a separate vLLM instance.
    """

    def __init__(
        self,
        model: str,
        base_url: str = "https://api.pinference.ai/api/v1",
        max_tokens: int = 2048,
        temperature: float = 0.0,
        input_price: float | None = None,
        output_price: float | None = None,
        max_cost_usd: float = 1.0,
        request=None,
        json_mode: bool = False,
        base_model: str | None = None,
        request_timeout: float = 90,
    ):
        if (
            input_price is None
            or output_price is None
            or not all(math.isfinite(p) and p >= 0 for p in (input_price, output_price))
        ):
            raise ValueError("Explicit current input/output prices per million tokens are required")
        if not math.isfinite(max_cost_usd) or max_cost_usd <= 0 or max_tokens <= 0:
            raise ValueError("A positive inference spending limit is required")
        self.model, self.base_url = model, base_url.rstrip("/")
        self.max_tokens, self.temperature = max_tokens, temperature
        self.input_price, self.output_price = input_price, output_price
        self.max_cost_usd, self.spent = max_cost_usd, 0.0
        self.request = request or self._request
        self.json_mode = json_mode
        self.base_model = base_model or model
        if not math.isfinite(request_timeout) or request_timeout <= 0:
            raise ValueError("request_timeout must be positive and finite")
        self.request_timeout = request_timeout

    def _request(self, payload: dict) -> dict:
        key = os.environ.get("PRIME_API_KEY")
        if not key:
            try:
                import httpx
                from prime_cli.api.inference import InferenceAPIError, InferenceClient
            except ImportError:
                raise RuntimeError(
                    "Set PRIME_API_KEY or install the prime extra and log in"
                ) from None

            try:
                # Use the official CLI's credential loader without copying or logging secrets.
                client = InferenceClient(timeout=self.request_timeout, inference_url=self.base_url)
                try:
                    return client.chat_completion(payload)
                finally:
                    client._client.close()
            except httpx.TimeoutException:
                raise RuntimeError("Prime inference request timed out") from None
            except (InferenceAPIError, httpx.HTTPError, OSError, ValueError) as exc:
                match = re.search(r"failed:\s*(\d{3})", str(exc))
                if match:
                    raise RuntimeError(f"Prime inference HTTP {match.group(1)}") from None
                raise RuntimeError(
                    "Prime inference unavailable; check CLI login and permissions"
                ) from None
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        if os.environ.get("PRIME_TEAM_ID"):
            headers["X-Prime-Team-ID"] = os.environ["PRIME_TEAM_ID"]
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions", data=json.dumps(payload).encode(), headers=headers
        )
        try:
            with urllib.request.urlopen(req, timeout=self.request_timeout) as response:
                return json.load(response)
        except urllib.error.HTTPError as exc:
            # Provider response bodies can contain private request details.
            raise RuntimeError(f"Inference HTTP {exc.code}; response body omitted") from None

    def run(self, session: EditSession) -> dict:
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(session.introduction())},
        ]
        tokens_in = tokens_out = 0
        started = time.perf_counter()
        failure = None
        while not session.done:
            # UTF-8 byte count is a deliberately conservative input-token bound.
            input_bound = len(json.dumps(messages, ensure_ascii=False).encode()) + 4096
            reserved = (
                input_bound * self.input_price + self.max_tokens * self.output_price
            ) / 1_000_000
            if self.spent + reserved > self.max_cost_usd:
                failure = "inference_budget_exhausted"
                break
            try:
                payload = {
                    "model": self.model,
                    "messages": messages,
                    "max_tokens": self.max_tokens,
                    "temperature": self.temperature,
                }
                if self.json_mode:
                    payload["response_format"] = {"type": "json_object"}
                reply = self.request(payload)
                usage = reply.get("usage")
                if not usage or "prompt_tokens" not in usage or "completion_tokens" not in usage:
                    # Charge the whole reservation and stop: do not silently undercount spending.
                    self.spent += reserved
                    failure = "missing_token_usage"
                    break
                ti, to = int(usage["prompt_tokens"]), int(usage["completion_tokens"])
                tokens_in += ti
                tokens_out += to
                self.spent += (ti * self.input_price + to * self.output_price) / 1_000_000
                text = reply["choices"][0]["message"]["content"]
                if not isinstance(text, str):
                    raise TypeError("Expected a text JSON action")
                session.model_trace.append(
                    {
                        "content": text,
                        "usage": usage,
                        "finish_reason": reply["choices"][0].get("finish_reason"),
                    }
                )
                result = session.respond(text)
                messages.extend(
                    [
                        {"role": "assistant", "content": text},
                        {"role": "user", "content": json.dumps(result)},
                    ]
                )
            except (RuntimeError, ValueError, TypeError, KeyError, IndexError, OSError) as exc:
                # A transport error can happen after the provider billed a request.
                self.spent += reserved
                failure = f"inference_error:{type(exc).__name__}"
                break
        return {
            "input_tokens": tokens_in,
            "output_tokens": tokens_out,
            "wall_seconds": time.perf_counter() - started,
            "failure": failure,
            "model": self.model,
            "temperature": self.temperature,
            "max_completion_tokens": self.max_tokens,
            "json_mode": self.json_mode,
            "estimated_cumulative_cost_usd": self.spent,
        }
