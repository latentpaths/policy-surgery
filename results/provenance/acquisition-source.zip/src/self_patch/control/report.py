"""Publish complete paired measurements and videos generated from frozen policies."""

import json
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from ..dataset import write_json
from .campaign import CACHE, Budget, paired
from .policy import Policy
from .world import CONDITIONS, episode


def render(root: Path, condition: str):
    protocol = json.loads((root / "protocol.json").read_text())
    runs = []
    for path in (root / "search").glob("*/frozen.json"):
        record = json.loads(path.read_text())
        if record["condition"] == condition:
            validation = next(
                v["score"]["mean_return"]
                for v in record["validation"]
                if v["candidate_id"] == record["selected"]["id"]
            )
            runs.append((path.parent, record, validation))
    editors = [r for r in runs if r[1]["method"].startswith("llm")]
    scripts = [r for r in runs if r[1]["method"] == "scripted"]
    if not editors or not scripts:
        return {"status": "missing_frozen_comparator", "condition": condition}
    # Video selection uses validation, never a favorable test episode/result.
    editor = max(editors, key=lambda r: r[2])
    script = max(scripts, key=lambda r: r[2])
    base = Policy.load(CACHE / "base.npz")
    models = [base, Policy.load(script[0] / "frozen.npz"), Policy.load(editor[0] / "frozen.npz")]
    seed = protocol["test_seeds"][0]
    episodes = [episode(model, CONDITIONS[condition], seed, render=True) for model in models]
    output = root / "videos" / condition
    if output.exists():
        raise FileExistsError("Video exports are immutable; use a fresh output")
    output.mkdir(parents=True)
    labels = ["Original pretrained policy", "Scripted weight search", "Frozen LLM weight editor"]
    details = ["No patch", script[0].name, editor[0].name]
    colors = ["#ff9787", "#f3cf7a", "#69e2b1"]
    width, height = 1920, 780
    font = lambda n: ImageFont.load_default(size=n)

    def compose(index):
        canvas = Image.new("RGB", (width, height), "#0a1120")
        draw = ImageDraw.Draw(canvas)
        draw.text(
            (42, 25), f"SELF-PATCH / {condition.replace('_', ' ')}", font=font(44), fill="#f4f7fb"
        )
        draw.text(
            (42, 85),
            "Pretrained lander. Changed physics. Frozen editor; direct weight edits.",
            font=font(25),
            fill="#abbad0",
        )
        for k, ep in enumerate(episodes):
            x = 30 + k * 640
            draw.text((x + 8, 145), labels[k], font=font(28), fill=colors[k])
            picture = Image.fromarray(ep["frames"][min(index, len(ep["frames"]) - 1)])
            canvas.paste(picture.resize((600, 400)), (x, 194))
            if index >= len(ep["frames"]) - 1:
                state = "SAFE LANDING" if ep["safe_landing"] else "FAILED / TIMED OUT"
                draw.text((x + 8, 616), state, font=font(23), fill=colors[k])
                draw.text(
                    (x + 8, 649),
                    f"Episode return: {ep['return']:.1f}",
                    font=font(23),
                    fill="#e6edf7",
                )
            draw.text((x + 8, 694), details[k], font=font(16), fill="#abbad0")
        draw.text(
            (42, 738),
            f"Illustrative fixed test seed {seed}; aggregate results use all 64 unseen starts. "
            "Editor chosen on validation only.",
            font=font(21),
            fill="#abbad0",
        )
        return canvas

    frames = max(len(e["frames"]) for e in episodes)
    compose(frames - 1).save(output / "poster.png")
    cmd = [
        "ffmpeg",
        "-loglevel",
        "error",
        "-y",
        "-f",
        "rawvideo",
        "-pix_fmt",
        "rgb24",
        "-s",
        f"{width}x{height}",
        "-r",
        "25",
        "-i",
        "-",
        "-an",
        "-c:v",
        "libx264",
        "-pix_fmt",
        "yuv420p",
        "-movflags",
        "+faststart",
        str(output / "replay.mp4"),
    ]
    with subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE) as process:
        for index in [*range(frames), *([frames - 1] * 50)]:
            process.stdin.write(compose(index).tobytes())
        process.stdin.close()
        error = process.stderr.read().decode()
        if process.wait():
            raise RuntimeError(error[:300])
    info = {
        "condition": condition,
        "test_seed": seed,
        "selection": "highest validation return",
        "selected_scripted_run": script[0].name,
        "selected_editor_run": editor[0].name,
        "actor_hashes": [m.digest() for m in models],
        "episodes": [{k: v for k, v in e.items() if k != "frames"} for e in episodes],
    }
    write_json(output / "replay.json", info)
    return {"video": str(output / "replay.mp4"), "returns": [e["return"] for e in episodes]}


def report(root: Path):
    summary = json.loads((root / "evaluation/summary.json").read_text())
    baseline = json.loads((root / "evaluation/unchanged.json").read_text())
    heuristic = json.loads((root / "evaluation/heuristic.json").read_text())
    lines = [
        "# Training-free controller edits on LunarLander",
        "",
        "The off-the-shelf language-model editor stays frozen. The target was trained",
        "upstream; here it receives direct weight edits, without fine-tuning or policy gradients.",
        "No editor, conversation, or observation/action wrapper is used at deployment.",
        "",
        "## Frozen evaluation",
        "",
        "Each row uses the same 64 previously unseen initial seeds for its condition.",
        "Primary metric: mean undiscounted episode return. 'Solved' means reward ≥200;",
        "safe landing is measured separately. Selection uses six development and twelve",
        "validation seeds, with a maximum of twelve proposals per search. Only the top",
        "three development candidates enter validation; test data never reach the editor.",
        "",
        "| Condition | Method / run | Return | Solved | Safe landing | Δ return vs original [95% paired CI] | Nominal Δ return |",
        "| --- | --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for condition, original in baseline.items():
        lines.append(
            f"| {condition} | unchanged | {original['mean_return']:.1f} | "
            f"{original['solution_rate']:.1%} | {original['safe_landing_rate']:.1%} | — | — |"
        )
        if condition in heuristic:
            h = heuristic[condition]
            lines.append(
                f"| {condition} | Gym heuristic (external controller) | {h['mean_return']:.1f} | "
                f"{h['solution_rate']:.1%} | {h['safe_landing_rate']:.1%} | — | — |"
            )
        for row in summary["runs"]:
            if row["condition"] != condition:
                continue
            score, difference = row["damaged"], row["return_difference"]
            lo, hi = difference["paired_seed_bootstrap_ci95"]
            lines.append(
                f"| {condition} | {row['method']} / {row['editor_seed']} | "
                f"{score['mean_return']:.1f} | {score['solution_rate']:.1%} | "
                f"{score['safe_landing_rate']:.1%} | {difference['mean_difference']:+.1f} "
                f"[{lo:+.1f}, {hi:+.1f}] | {row['nominal_difference']['mean_difference']:+.1f} |"
            )
    lines += [
        "",
        "## LLM versus scripted weight search",
        "",
        "| Condition | Editor / run | Paired return advantage over scripted [95% CI] |",
        "| --- | --- | ---: |",
    ]
    head_to_head = []
    for row in summary["runs"]:
        if not row["method"].startswith("llm"):
            continue
        comparators = [
            r
            for r in summary["runs"]
            if r["condition"] == row["condition"] and r["method"] == "scripted"
        ]
        if not comparators:
            continue
        comparator = comparators[0]
        difference = paired(comparator["damaged"], row["damaged"])
        head_to_head.append({"run": row["run"], "comparator": comparator["run"], **difference})
        lo, hi = difference["paired_seed_bootstrap_ci95"]
        lines.append(
            f"| {row['condition']} | {row['method']} / {row['editor_seed']} | "
            f"{difference['mean_difference']:+.1f} [{lo:+.1f}, {hi:+.1f}] |"
        )
    write_json(root / "evaluation/head-to-head.json", head_to_head)
    lines += [
        "",
        "## How to interpret this",
        "",
        "The combined-physics GLM patch raises mean return from −97.1 to −11.0, but",
        "reward≥200 success falls from 15.6% to 12.5%. Safe landings rise only from",
        "21.9% to 25.0%, and nominal mean return drops by 58.7 points. The reward gain",
        "is not evidence of a reliable repair. Wind and weak-thrust results do not",
        "establish improvement over unchanged weights.",
        "",
        "Mirrored thrusters is a sanity check: swapping two output rows exactly undoes",
        "the action reversal. It is not the main research result. The harder conditions",
        "change maximum available thrust, wind/torque, or multiple physical properties.",
        "These conditions can require a different control strategy rather than a global",
        "linear inverse. Weak thrust can reduce reward while still allowing safe landing.",
        "",
        "Scripted search is an adaptive random search over input gains and action-logit",
        "biases. It has the same proposal cap and selection protocol. The LLM additionally",
        "has typed access to individual weight rows and arbitrary bounded scalar edits,",
        "so this comparison does not isolate reasoning from differences in search space.",
        "Actual proposal counts and all failed candidates are preserved in run manifests.",
        "Three inference requests had unknown outcomes; their upper-bound costs stay",
        "reserved. The weak-thrust GPT-OSS run stopped after one candidate. Two initial",
        "GLM runs stopped before proposing any candidate; later attempts completed.",
        "One scripted sanity run hit an integer-array casting bug after four proposals;",
        "it is retained as failed, and the corrected run is reported separately.",
        "",
        "Nominal regression measures a context-specific tradeoff, not mechanistic",
        "proof of forgetting. In the reversal case it is expected: the same observation",
        "requires opposite actions under opposite actuator mappings. Restoring the original",
        "checkpoint restores the appropriate original-domain controller.",
        "The GLM run index is not a provider sampling seed; provider seed support is",
        "recorded in editor.json. Only one completed stochastic search per editor and",
        "condition was measured, so editor-run variability remains unmeasured.",
        "",
        "Intervals bootstrap paired initial seeds (2,000 resamples). They describe",
        "variation across starts for one pretrained target, not across target networks",
        "or editor training seeds. These are exploratory comparisons without correction",
        "for multiple conditions; no general self-improvement claim follows.",
        "",
        "## Provenance and cost",
        "",
        (
            f"Target: [{summary['protocol']['source']['repo']}](https://huggingface.co/"
            f"{summary['protocol']['source']['repo']}) at revision "
            f"`{summary['protocol']['source']['revision']}`. The actor was trained upstream"
        ),
        "on LunarLander-v2 and is measured here on Gymnasium 1.4.0's LunarLander-v3.",
        "The original Torch actor and imported NumPy actor agree on 1,024 sampled actions;",
        "the exact measured numerical error and both tensor/source hashes are in protocol.json.",
        "Upstream weights retain upstream terms; the task manifests and edit operations",
        "are the new experiment artifacts. No upstream training-score reproduction is claimed.",
        "",
        f"Current durable inference ledger: {json.dumps(Budget().summary())}.",
        "Costs use conservative catalog token rates; unknown request outcomes retain",
        "their reserved upper bounds. This campaign's inference allowance is $20, within",
        "the user's $500 project ceiling. No GPU instance was rented: controller and",
        "Box2D execution are local CPU work; the language-model editor uses Prime inference.",
        "",
        "[Environment specification](https://gymnasium.farama.org/environments/box2d/lunar_lander/)",
        "",
    ]
    (root / "REPORT.md").write_text("\n".join(lines))
    return {"report": str(root / "REPORT.md"), "runs": len(summary["runs"])}


def export_tasks(root: Path, destination: Path):
    protocol = json.loads((root / "protocol.json").read_text())
    records = []
    for split, seeds in (
        ("development", protocol["development_seeds"]),
        ("validation", protocol["validation_seeds"]),
        ("test", protocol["test_seeds"]),
    ):
        for condition, physics in protocol["conditions"].items():
            for seed in seeds:
                records.append(
                    {
                        "id": f"{condition}-{split}-{seed}",
                        "split": split,
                        "environment": protocol["environment"],
                        "episode_seed": seed,
                        "physics": physics,
                        "target": protocol["source"],
                        "protocol_sha256": protocol["protocol_sha256"],
                    }
                )
    destination.mkdir(parents=True, exist_ok=True)
    (destination / "tasks.jsonl").write_text("".join(json.dumps(r) + "\n" for r in records))
    write_json(destination / "protocol.json", protocol)
    return {"tasks": len(records), "path": str(destination / "tasks.jsonl")}
