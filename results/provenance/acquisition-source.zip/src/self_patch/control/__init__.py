"""Training-free weight-editing experiments on a pretrained Box2D lander."""
