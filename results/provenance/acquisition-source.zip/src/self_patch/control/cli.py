"""Run training-free Box2D searches, frozen evaluations, and evidence exports."""

import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "action",
        choices=[
            "prepare",
            "search",
            "evaluate",
            "report",
            "render",
            "export",
            "gate-init",
            "gate-select",
            "gate-approve",
            "gate-test",
            "gate-report",
        ],
    )
    parser.add_argument("--root", type=Path)
    parser.add_argument("--source", type=Path, default=Path("results/control-completion-search-v1"))
    parser.add_argument("--objective", choices=["completion", "reward"], default="completion")
    parser.add_argument("--condition", default="crosswind")
    parser.add_argument("--method", choices=["llm", "llm-glm", "scripted"], default="llm")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--model")
    parser.add_argument("--input-price", type=float)
    parser.add_argument("--output-price", type=float)
    args = parser.parse_args()
    if args.root is None:
        args.root = Path(
            "results/control-completion-v1"
            if args.action.startswith("gate-")
            else "results/control-completion-search-v1"
            if args.objective == "completion"
            else "results/control-v2"
        )
    try:
        from .campaign import Search, final_evaluation, llm, prepare, read_protocol, scripted
        from .report import export_tasks, render, report

        if (
            args.action in ("report", "render", "export")
            and read_protocol(args.root).get("objective") == "completion"
        ):
            raise ValueError(
                "Completion searches require the gate workflow; use gate-report after gate-test"
            )
        if args.action.startswith("gate-"):
            from . import acceptance

            if args.action == "gate-init":
                result = acceptance.initialize(args.source, args.root)
            elif args.action == "gate-select":
                result = acceptance.select(args.root)
            elif args.action == "gate-approve":
                result = acceptance.approve(args.root)
            elif args.action == "gate-test":
                result = acceptance.test(args.root)
            else:
                result = acceptance.report(args.root)
            if isinstance(result, list):
                result = [
                    {k: r.get(k) for k in ("run", "accepted", "decision_reasons")} for r in result
                ]
            elif "runs" in result and isinstance(result["runs"], list):
                result = [
                    {k: r.get(k) for k in ("run", "accepted", "reason", "reasons")}
                    for r in result["runs"]
                ]
        elif args.action == "prepare":
            result = prepare(args.root, objective=args.objective)
        elif args.action == "search":
            model = args.model or (
                "z-ai/glm-5.3" if args.method == "llm-glm" else "openai/gpt-oss-120b"
            )
            if args.method != "scripted":
                from prime_cli.api.inference import InferenceClient

                client = InferenceClient()
                try:
                    pricing = client.retrieve_model(model)["pricing"]
                finally:
                    client._client.close()
                input_price = (
                    args.input_price
                    if args.input_price is not None
                    else pricing["input_usd_per_mtok"]
                )
                output_price = (
                    args.output_price
                    if args.output_price is not None
                    else pricing["output_usd_per_mtok"]
                )
                if (
                    input_price < pricing["input_usd_per_mtok"]
                    or output_price < pricing["output_usd_per_mtok"]
                ):
                    raise ValueError("Supplied prices understate the current Prime catalog quote")
            search = Search(args.root, args.condition, args.method, args.seed)
            result = (
                scripted(search)
                if args.method == "scripted"
                else llm(search, model, input_price, output_price)
            )
        elif args.action == "evaluate":
            result = final_evaluation(args.root)
        elif args.action == "report":
            result = report(args.root)
        elif args.action == "render":
            result = render(args.root, args.condition)
        else:
            result = export_tasks(args.root, Path("data/control-v2"))
        print(json.dumps(result, indent=2))
    except ImportError:
        parser.exit(1, "Install self-patch[control,prime] for the controller experiments.\n")
    except (OSError, ValueError, KeyError, RuntimeError) as exc:
        parser.exit(1, f"{exc}\n")


if __name__ == "__main__":
    main()
